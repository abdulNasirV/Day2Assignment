﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnAssignment2
{
    class Program
    {
        public static void main(String[] args)
        {
            DateTime month;


            double debt = 1000.00;

            using (MemoryStream memory = new MemoryStream()) ;
            using (BufferedStream stream = new BufferedStream(memory)) ;
                Console.WriteLine("Enterhly Installment:")
                 double monthly_payment = 

            while (debt & gt; 0)
 {
                debt *= 1.015;
                debt -= monthly_payment;
                if (debt & lt;= 0)
   {
                    monthly_payment = 0 - debt;
                    debt = 0;
                }
                month = month + 1;
                payments = payments + monthly_payment;

                System.out.println("Monthonths+", Balance: "+debt+", Payments: "+monthly_payments);
 }
        }
    }
}
